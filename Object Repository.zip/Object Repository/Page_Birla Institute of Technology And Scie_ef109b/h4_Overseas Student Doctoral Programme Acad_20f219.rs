<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h4_Overseas Student Doctoral Programme Acad_20f219</name>
   <tag></tag>
   <elementGuidId>0cee385a-3f9f-4c20-a322-d0f25626960c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Latest Updates'])[1]/following::h4[1]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>a.appl_bts.t_b > h4</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Overseas Student Doctoral Programme Academic Year 2023-24 read more&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h4</value>
      <webElementGuid>f815a6f5-2b19-4f4d-9ca3-f20ef407be41</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Overseas Student Doctoral Programme Academic Year 2023-24</value>
      <webElementGuid>cef6ef83-1837-466e-98b5-32696567ed3f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;js&quot;]/body[@class=&quot;home page-template page-template-template-home page-template-template-home-php page page-id-2740 page-parent noptin mfn-header-template color-custom content-brightness-light input-brightness-light style-default button-default layout-full-width if-modern-overlay subheader-both-center mobile-tb-center mobile-side-slide mobile-mini-mr-ll mobile-icon-user-ss mobile-icon-wishlist-ss mobile-icon-search-ss mobile-icon-wpml-ss mobile-icon-action-ss be-page-2740 be-reg-26408 mfn-header-scrolled fixed-breadcrumb&quot;]/div[@class=&quot;home_grid-min6&quot;]/div[@class=&quot;secbox_col&quot;]/div[@class=&quot;home_grid-ann3&quot;]/div[@class=&quot;home_grid-ann1_cont2&quot;]/div[@class=&quot;pr h-100&quot;]/a[@class=&quot;appl_bts t_b&quot;]/h4[1]</value>
      <webElementGuid>48ffb0a4-8b06-4eea-9d7b-02e818700093</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Latest Updates'])[1]/following::h4[1]</value>
      <webElementGuid>a0d711bc-3ed7-4541-8a60-7476f6cec216</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='work@BITS'])[1]/following::h4[1]</value>
      <webElementGuid>02b05282-8997-441f-9be6-02a55ec68ebb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Loading...'])[1]/preceding::h4[1]</value>
      <webElementGuid>cdd1fa0f-74f4-4214-a7d1-749c1da7ec91</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Keep Exploring'])[1]/preceding::h4[1]</value>
      <webElementGuid>a2a0e150-e98d-4e2f-8a7e-3d23b7bc0658</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/a/h4</value>
      <webElementGuid>e2d6e510-2ed1-4ffe-9063-f567f86ae9eb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h4[(text() = 'Overseas Student Doctoral Programme Academic Year 2023-24' or . = 'Overseas Student Doctoral Programme Academic Year 2023-24')]</value>
      <webElementGuid>bce60f25-237d-4604-a3c8-958236720ca5</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
