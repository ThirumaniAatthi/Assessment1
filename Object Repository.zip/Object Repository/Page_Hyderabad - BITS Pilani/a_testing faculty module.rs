<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_testing faculty module</name>
   <tag></tag>
   <elementGuidId>ada60547-9d95-487a-a149-27d9db2cda77</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='Content']/div/div/div/div/div[3]/div[2]/div/div/div[2]/div/div/div/div/ul/li[2]/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.announcement-left-inner > ul > li:nth-of-type(2) > a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;testing faculty module&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>b98430a8-b4a7-4452-b4d3-356dd7c48dec</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://www.bits-pilani.ac.in/news/testing-faculty-module/</value>
      <webElementGuid>3e560330-9116-4edf-b386-45431758fedc</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>testing faculty module</value>
      <webElementGuid>dcaadeef-eb01-4f65-a510-4a185b7c62ea</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;Content&quot;)/div[@class=&quot;content_wrapper clearfix&quot;]/div[@class=&quot;sections_group&quot;]/div[@class=&quot;entry-content&quot;]/div[@class=&quot;mfn-builder-content mfn-default-content-buider&quot;]/div[@class=&quot;section mcb-section mfn-default-section mcb-section-73dae138f container full-width&quot;]/div[@class=&quot;section_wrapper mcb-section-inner mcb-section-inner-73dae138f&quot;]/div[@class=&quot;wrap mcb-wrap mcb-wrap-e793ad282 two-fifth tablet-two-fifth mobile-one page-overview-left-title clearfix&quot;]/div[@class=&quot;mcb-wrap-inner mcb-wrap-inner-e793ad282&quot;]/div[@class=&quot;column mcb-column mcb-item-f2da733fc one tablet-one mobile-one column_column&quot;]/div[@class=&quot;mcb-column-inner mcb-column-inner-f2da733fc mcb-item-column-inner&quot;]/div[@class=&quot;column_attr mfn-inline-editor clearfix&quot;]/div[@class=&quot;placement-announcement-left&quot;]/div[@class=&quot;announcement-left-inner&quot;]/ul[1]/li[2]/a[1]</value>
      <webElementGuid>03f7710b-39f6-468a-a74c-097f44df99ff</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='Content']/div/div/div/div/div[3]/div[2]/div/div/div[2]/div/div/div/div/ul/li[2]/a</value>
      <webElementGuid>9f82694a-c7cd-4b05-89c0-58cf69bbf4d6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'testing faculty module')]</value>
      <webElementGuid>fb6d4bcf-a650-4d00-b718-0ac6a1e6b8f8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='AGANIT – Newsletter'])[1]/following::a[1]</value>
      <webElementGuid>4c2f4eb1-aff2-4a94-be8e-2c226d5648e8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Announcement'])[1]/following::a[2]</value>
      <webElementGuid>05648a59-0bf3-489d-9bab-317576d40c44</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='The Indian Mathematical Society (IMS)-2023'])[3]/preceding::a[1]</value>
      <webElementGuid>c3eb9f85-e4b4-4056-9c1c-5573db4ab6fa</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='National Symposium on Convergence of Chemistry &amp; Materials (CCM-2023)'])[1]/preceding::a[2]</value>
      <webElementGuid>1b2462e7-e933-4fba-9a2c-cb0e83556d2b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='testing faculty module']/parent::*</value>
      <webElementGuid>65f3cc9a-b06f-4755-9d61-9a9c50b57f09</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'https://www.bits-pilani.ac.in/news/testing-faculty-module/')]</value>
      <webElementGuid>3598c384-3016-4bf3-ac59-703fb9c55c58</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/div/div/div/ul/li[2]/a</value>
      <webElementGuid>eeff8ebe-f2d9-4616-bca4-62502874f362</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://www.bits-pilani.ac.in/news/testing-faculty-module/' and (text() = 'testing faculty module' or . = 'testing faculty module')]</value>
      <webElementGuid>3e19f2f6-597e-4e28-a6fe-83d8174d26d7</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
