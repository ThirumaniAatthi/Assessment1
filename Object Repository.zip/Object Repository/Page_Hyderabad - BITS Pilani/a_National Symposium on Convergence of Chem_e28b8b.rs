<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_National Symposium on Convergence of Chem_e28b8b</name>
   <tag></tag>
   <elementGuidId>d1eeaec4-3584-4297-a23a-750855118273</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='Content']/div/div/div/div/div[3]/div[2]/div/div/div[2]/div/div/div/div/ul/li[4]/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.announcement-left-inner > ul > li:nth-of-type(4) > a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;National Symposium on Convergence of Chemistry &amp; Materials (CCM-2023)&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>8fa147b4-f8ea-43fc-9ecc-8a201dd6504d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://www.bits-pilani.ac.in/news/ccm-2023/</value>
      <webElementGuid>0df74599-6e5a-4604-855a-f51fabd258cd</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>National Symposium on Convergence of Chemistry &amp; Materials (CCM-2023)</value>
      <webElementGuid>0b37651c-c3db-4730-9de0-6780c5f7b8ad</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;Content&quot;)/div[@class=&quot;content_wrapper clearfix&quot;]/div[@class=&quot;sections_group&quot;]/div[@class=&quot;entry-content&quot;]/div[@class=&quot;mfn-builder-content mfn-default-content-buider&quot;]/div[@class=&quot;section mcb-section mfn-default-section mcb-section-73dae138f container full-width&quot;]/div[@class=&quot;section_wrapper mcb-section-inner mcb-section-inner-73dae138f&quot;]/div[@class=&quot;wrap mcb-wrap mcb-wrap-e793ad282 two-fifth tablet-two-fifth mobile-one page-overview-left-title clearfix&quot;]/div[@class=&quot;mcb-wrap-inner mcb-wrap-inner-e793ad282&quot;]/div[@class=&quot;column mcb-column mcb-item-f2da733fc one tablet-one mobile-one column_column&quot;]/div[@class=&quot;mcb-column-inner mcb-column-inner-f2da733fc mcb-item-column-inner&quot;]/div[@class=&quot;column_attr mfn-inline-editor clearfix&quot;]/div[@class=&quot;placement-announcement-left&quot;]/div[@class=&quot;announcement-left-inner&quot;]/ul[1]/li[4]/a[1]</value>
      <webElementGuid>1d1703aa-089b-42b0-a5ce-9a1706fc4533</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='Content']/div/div/div/div/div[3]/div[2]/div/div/div[2]/div/div/div/div/ul/li[4]/a</value>
      <webElementGuid>1e00a550-7f16-45ca-83f7-347b9e6d8e7f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'National Symposium on Convergence of Chemistry &amp; Materials (CCM-2023)')]</value>
      <webElementGuid>9a08ea99-34b0-4801-9a10-5ad0a8116719</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='The Indian Mathematical Society (IMS)-2023'])[3]/following::a[1]</value>
      <webElementGuid>1e90a8de-a06f-426f-8f29-8037b1afa0a4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='testing faculty module'])[1]/following::a[2]</value>
      <webElementGuid>edc8127c-09ba-4e63-86b4-02bee41f5eaa</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Why recruit from BITS Pilani, Hyderabad Campus?'])[1]/preceding::a[1]</value>
      <webElementGuid>04c6adf2-6c3a-4ba9-af72-9cde295949b2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Stringent student selection'])[1]/preceding::a[1]</value>
      <webElementGuid>a97ed203-c7db-4dda-977f-5e800e8b4f3d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='National Symposium on Convergence of Chemistry &amp; Materials (CCM-2023)']/parent::*</value>
      <webElementGuid>c5c06bc1-7494-494b-9df9-c3e50a1a92f0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>(//a[contains(@href, 'https://www.bits-pilani.ac.in/news/ccm-2023/')])[4]</value>
      <webElementGuid>f9e4a42e-fd68-42f2-a362-29d086adcd70</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/div/div/div/ul/li[4]/a</value>
      <webElementGuid>4434cc3b-05b0-4b8a-81d7-4549ccb8bbbb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://www.bits-pilani.ac.in/news/ccm-2023/' and (text() = 'National Symposium on Convergence of Chemistry &amp; Materials (CCM-2023)' or . = 'National Symposium on Convergence of Chemistry &amp; Materials (CCM-2023)')]</value>
      <webElementGuid>3da18b54-b1d2-4087-9424-55dbcb0c2466</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
