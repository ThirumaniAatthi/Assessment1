<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_AGANIT  Newsletter</name>
   <tag></tag>
   <elementGuidId>7e45735f-a920-4b84-924b-5458463332be</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='Content']/div/div/div/div/div[3]/div[2]/div/div/div[2]/div/div/div/div/ul/li/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.announcement-left-inner > ul > li > a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;AGANIT – Newsletter&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>69e31891-b567-4502-8f03-5a90e8e43594</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://www.bits-pilani.ac.in/news/aganit-newsletter/</value>
      <webElementGuid>3e7a461f-1d7a-4868-ae45-1fe6b703b3af</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>AGANIT – Newsletter</value>
      <webElementGuid>0f53d273-3395-4249-97f2-0fc5157d067a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;Content&quot;)/div[@class=&quot;content_wrapper clearfix&quot;]/div[@class=&quot;sections_group&quot;]/div[@class=&quot;entry-content&quot;]/div[@class=&quot;mfn-builder-content mfn-default-content-buider&quot;]/div[@class=&quot;section mcb-section mfn-default-section mcb-section-73dae138f container full-width&quot;]/div[@class=&quot;section_wrapper mcb-section-inner mcb-section-inner-73dae138f&quot;]/div[@class=&quot;wrap mcb-wrap mcb-wrap-e793ad282 two-fifth tablet-two-fifth mobile-one page-overview-left-title clearfix&quot;]/div[@class=&quot;mcb-wrap-inner mcb-wrap-inner-e793ad282&quot;]/div[@class=&quot;column mcb-column mcb-item-f2da733fc one tablet-one mobile-one column_column&quot;]/div[@class=&quot;mcb-column-inner mcb-column-inner-f2da733fc mcb-item-column-inner&quot;]/div[@class=&quot;column_attr mfn-inline-editor clearfix&quot;]/div[@class=&quot;placement-announcement-left&quot;]/div[@class=&quot;announcement-left-inner&quot;]/ul[1]/li[1]/a[1]</value>
      <webElementGuid>b76a3f8e-62e5-4375-967f-c8c2b45526e3</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='Content']/div/div/div/div/div[3]/div[2]/div/div/div[2]/div/div/div/div/ul/li/a</value>
      <webElementGuid>d63adbe5-9143-496f-86ce-0d0258dae68f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'AGANIT – Newsletter')]</value>
      <webElementGuid>24c8eb34-f738-41ba-bb81-e2befab3d936</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Announcement'])[1]/following::a[1]</value>
      <webElementGuid>86b00ec1-321f-46ed-8f3d-5f17f47407c3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='HYDERABAD'])[1]/following::a[1]</value>
      <webElementGuid>aed2ce47-55b3-4996-8a91-f0a63fab876d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='testing faculty module'])[1]/preceding::a[1]</value>
      <webElementGuid>90d5d9dc-a7eb-4b2b-9034-5a20c7288134</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='The Indian Mathematical Society (IMS)-2023'])[3]/preceding::a[2]</value>
      <webElementGuid>c5c506c1-a126-49ba-acb7-82d88eefed05</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='AGANIT – Newsletter']/parent::*</value>
      <webElementGuid>2e9566e4-a744-4600-afd7-ddf110c5bcc5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'https://www.bits-pilani.ac.in/news/aganit-newsletter/')]</value>
      <webElementGuid>d066755d-02ac-46cb-9c79-fe278cf87941</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/div/div/div/ul/li/a</value>
      <webElementGuid>b2fdb2e3-4c00-4b0f-9714-2a444730c9af</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://www.bits-pilani.ac.in/news/aganit-newsletter/' and (text() = 'AGANIT – Newsletter' or . = 'AGANIT – Newsletter')]</value>
      <webElementGuid>4b816120-8aff-4d0a-a98e-414f7d557555</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
