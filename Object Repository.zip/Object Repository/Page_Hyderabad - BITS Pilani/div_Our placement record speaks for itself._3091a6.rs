<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Our placement record speaks for itself._3091a6</name>
   <tag></tag>
   <elementGuidId>64b9c32a-8f55-4b26-be9f-2df225c3aae9</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='Content']/div/div/div/div/div[3]/div[2]/div[2]/div/div[3]/div/div</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.mcb-column-inner.mcb-column-inner-abf87449e.mcb-item-column-inner > div.column_attr.mfn-inline-editor.clearfix</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>div:nth-child(3) > .mcb-column-inner > .column_attr >> nth=0</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>d42bc68c-74f6-4341-8394-072e31915ce0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>column_attr mfn-inline-editor clearfix</value>
      <webElementGuid>e9387260-9c2d-48a3-afe5-edc514108e8d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Our placement record speaks for itself. More than 250 large and medium sized companies visit our campus every year to recruit our students. As per year on year(YoY) placement statistics, around 91% of our students(First degree &amp; Higher degree) who are interested in securing jobs through campus placements succeed in doing so. As a result, most of our students have their career paths chartered much before graduation.  This is a validation of the quality of education and experience they get at BITS Pilani-Hyderabad Campus.BITS Pilani-Hyderabad Campus is one of the most sought after Institutes among recruiters. Students are admitted based on the same criteria across the four campuses. Students are selected only on merit, and given the best facilities to encourage all-round development. Some salient features of our education process are as follows :Stringent student selectionWorld class curriculum and facultyMinor programs in Data Science and FinanceStudents with hands-on industry experience through the Practice School ProgramStudents with exposure to numerous extra-curricular activitiesExcellent infrastructure &amp; communication facilities </value>
      <webElementGuid>0bf4db4f-8533-4e97-aebc-51cda648c721</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;Content&quot;)/div[@class=&quot;content_wrapper clearfix&quot;]/div[@class=&quot;sections_group&quot;]/div[@class=&quot;entry-content&quot;]/div[@class=&quot;mfn-builder-content mfn-default-content-buider&quot;]/div[@class=&quot;section mcb-section mfn-default-section mcb-section-73dae138f container full-width&quot;]/div[@class=&quot;section_wrapper mcb-section-inner mcb-section-inner-73dae138f&quot;]/div[@class=&quot;wrap mcb-wrap mcb-wrap-91a1d993b three-fifth tablet-three-fifth mobile-one page-overview-right clearfix&quot;]/div[@class=&quot;mcb-wrap-inner mcb-wrap-inner-91a1d993b&quot;]/div[@class=&quot;column mcb-column mcb-item-abf87449e one tablet-one mobile-one column_column&quot;]/div[@class=&quot;mcb-column-inner mcb-column-inner-abf87449e mcb-item-column-inner&quot;]/div[@class=&quot;column_attr mfn-inline-editor clearfix&quot;]</value>
      <webElementGuid>a7085774-9670-4c55-a548-08239e9a9ca1</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='Content']/div/div/div/div/div[3]/div[2]/div[2]/div/div[3]/div/div</value>
      <webElementGuid>2a1b3c43-cb86-44d0-a585-ca5d4baab885</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Why recruit from BITS Pilani, Hyderabad Campus?'])[1]/following::div[3]</value>
      <webElementGuid>732d43ec-94bb-4927-8943-c953b7eb4ab5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='National Symposium on Convergence of Chemistry &amp; Materials (CCM-2023)'])[1]/following::div[8]</value>
      <webElementGuid>6d05d074-6df8-4ae3-9ce9-3e4c2a169e37</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/div[3]/div/div</value>
      <webElementGuid>bfe70b1f-cb99-4abe-97d4-7397f9ec936c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'Our placement record speaks for itself. More than 250 large and medium sized companies visit our campus every year to recruit our students. As per year on year(YoY) placement statistics, around 91% of our students(First degree &amp; Higher degree) who are interested in securing jobs through campus placements succeed in doing so. As a result, most of our students have their career paths chartered much before graduation.  This is a validation of the quality of education and experience they get at BITS Pilani-Hyderabad Campus.BITS Pilani-Hyderabad Campus is one of the most sought after Institutes among recruiters. Students are admitted based on the same criteria across the four campuses. Students are selected only on merit, and given the best facilities to encourage all-round development. Some salient features of our education process are as follows :Stringent student selectionWorld class curriculum and facultyMinor programs in Data Science and FinanceStudents with hands-on industry experience through the Practice School ProgramStudents with exposure to numerous extra-curricular activitiesExcellent infrastructure &amp; communication facilities ' or . = 'Our placement record speaks for itself. More than 250 large and medium sized companies visit our campus every year to recruit our students. As per year on year(YoY) placement statistics, around 91% of our students(First degree &amp; Higher degree) who are interested in securing jobs through campus placements succeed in doing so. As a result, most of our students have their career paths chartered much before graduation.  This is a validation of the quality of education and experience they get at BITS Pilani-Hyderabad Campus.BITS Pilani-Hyderabad Campus is one of the most sought after Institutes among recruiters. Students are admitted based on the same criteria across the four campuses. Students are selected only on merit, and given the best facilities to encourage all-round development. Some salient features of our education process are as follows :Stringent student selectionWorld class curriculum and facultyMinor programs in Data Science and FinanceStudents with hands-on industry experience through the Practice School ProgramStudents with exposure to numerous extra-curricular activitiesExcellent infrastructure &amp; communication facilities ')]</value>
      <webElementGuid>8c0b57b6-b867-498a-81f2-0da62153a513</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
