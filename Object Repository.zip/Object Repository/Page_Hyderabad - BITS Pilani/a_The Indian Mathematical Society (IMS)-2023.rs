<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_The Indian Mathematical Society (IMS)-2023</name>
   <tag></tag>
   <elementGuidId>25007a65-6e54-41b2-82df-9466ea31dee4</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='Content']/div/div/div/div/div[3]/div[2]/div/div/div[2]/div/div/div/div/ul/li[3]/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.announcement-left-inner > ul > li:nth-of-type(3) > a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;The Indian Mathematical Society (IMS)-2023&quot;s]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>5b924d62-c94d-4a13-a0bd-abfa1152e48e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://www.bits-pilani.ac.in/news/the-indian-mathematical-society-ims-2023/</value>
      <webElementGuid>1e56adae-85ba-4282-84dd-c44c83cf4aef</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>The Indian Mathematical Society (IMS)-2023</value>
      <webElementGuid>ac7d84c1-9078-48c3-b7f7-4741dc7645ba</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;Content&quot;)/div[@class=&quot;content_wrapper clearfix&quot;]/div[@class=&quot;sections_group&quot;]/div[@class=&quot;entry-content&quot;]/div[@class=&quot;mfn-builder-content mfn-default-content-buider&quot;]/div[@class=&quot;section mcb-section mfn-default-section mcb-section-73dae138f container full-width&quot;]/div[@class=&quot;section_wrapper mcb-section-inner mcb-section-inner-73dae138f&quot;]/div[@class=&quot;wrap mcb-wrap mcb-wrap-e793ad282 two-fifth tablet-two-fifth mobile-one page-overview-left-title clearfix&quot;]/div[@class=&quot;mcb-wrap-inner mcb-wrap-inner-e793ad282&quot;]/div[@class=&quot;column mcb-column mcb-item-f2da733fc one tablet-one mobile-one column_column&quot;]/div[@class=&quot;mcb-column-inner mcb-column-inner-f2da733fc mcb-item-column-inner&quot;]/div[@class=&quot;column_attr mfn-inline-editor clearfix&quot;]/div[@class=&quot;placement-announcement-left&quot;]/div[@class=&quot;announcement-left-inner&quot;]/ul[1]/li[3]/a[1]</value>
      <webElementGuid>1b1ed9d8-eb4e-421d-ad2c-1d95ff15d6f3</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='Content']/div/div/div/div/div[3]/div[2]/div/div/div[2]/div/div/div/div/ul/li[3]/a</value>
      <webElementGuid>e61c993e-ae53-4d3f-87d5-c4163aa8fa94</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'The Indian Mathematical Society (IMS)-2023')]</value>
      <webElementGuid>1e7dc7ce-596f-4275-821c-61686b6dac92</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='testing faculty module'])[1]/following::a[1]</value>
      <webElementGuid>4c65ed64-b2dd-4591-80ef-2d428f2d6053</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='AGANIT – Newsletter'])[1]/following::a[2]</value>
      <webElementGuid>f5dc9a20-f158-4172-84ec-13dbf186690e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='National Symposium on Convergence of Chemistry &amp; Materials (CCM-2023)'])[1]/preceding::a[1]</value>
      <webElementGuid>be0269ee-7627-4f48-8add-d3654e664f18</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Why recruit from BITS Pilani, Hyderabad Campus?'])[1]/preceding::a[2]</value>
      <webElementGuid>a367a66e-e0ad-453c-b7a1-2c0b3f5d5159</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>(//a[contains(@href, 'https://www.bits-pilani.ac.in/news/the-indian-mathematical-society-ims-2023/')])[3]</value>
      <webElementGuid>bbb517f6-38f1-489c-a621-ce109a9f8639</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/div/div/div/ul/li[3]/a</value>
      <webElementGuid>38ce7ef6-18d8-41fb-89df-92c1b8c6b211</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://www.bits-pilani.ac.in/news/the-indian-mathematical-society-ims-2023/' and (text() = 'The Indian Mathematical Society (IMS)-2023' or . = 'The Indian Mathematical Society (IMS)-2023')]</value>
      <webElementGuid>9d2463bc-80e6-4008-9640-cb60fd123131</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
