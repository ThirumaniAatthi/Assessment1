<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>ul_Category  Symposium                     _c509e4</name>
   <tag></tag>
   <elementGuidId>e3a75836-8a6b-4d31-822a-a5dc32d06232</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='events-filters']/section/div/div/div[2]/div/div[2]/div[2]/ul</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.sec-li > ul</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;Category : Symposium Type : Offline&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>ul</value>
      <webElementGuid>c08f66dc-db93-452f-a418-eaf88b03b314</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                                                                                                
                                                    
                                                        Category : Symposium
                                                    
                                                
                                                
                                                    
                                                        Type : Offline
                                                    
                                                
                                            </value>
      <webElementGuid>5a9494aa-a5cc-4823-897b-28068795d221</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;events-filters&quot;)/section[1]/div[@class=&quot;container&quot;]/div[@class=&quot;smr-sec09&quot;]/div[@class=&quot;smr-sec-2&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-8&quot;]/div[@class=&quot;sec-li&quot;]/ul[1]</value>
      <webElementGuid>ffe68946-e498-4f19-adfa-9d773aae72e8</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='events-filters']/section/div/div/div[2]/div/div[2]/div[2]/ul</value>
      <webElementGuid>4d362334-90ec-415d-b002-60646a9df452</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='June 16, 2024 To June 21, 2024'])[1]/following::ul[1]</value>
      <webElementGuid>840649c0-bfad-4c6b-b760-ec921b830ce8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='results 1-3 of 3'])[1]/following::ul[1]</value>
      <webElementGuid>585ee24e-3836-4f4e-90de-0e25b312a000</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/ul</value>
      <webElementGuid>64cf3024-f8dd-4482-ad1a-12c81538dc12</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//ul[(text() = '
                                                                                                
                                                    
                                                        Category : Symposium
                                                    
                                                
                                                
                                                    
                                                        Type : Offline
                                                    
                                                
                                            ' or . = '
                                                                                                
                                                    
                                                        Category : Symposium
                                                    
                                                
                                                
                                                    
                                                        Type : Offline
                                                    
                                                
                                            ')]</value>
      <webElementGuid>0f4c1d63-da62-4eda-99e3-c467c6818b3c</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
