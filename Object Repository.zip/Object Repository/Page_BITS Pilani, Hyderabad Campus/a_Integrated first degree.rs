<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Integrated first degree</name>
   <tag></tag>
   <elementGuidId>0a490e62-1988-461f-98da-a13b6ffcadc7</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(//a[contains(text(),'Integrated first degree')])[4]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>div >> internal:has-text=/^Integrated first degree$/ >> internal:role=link</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>60f43195-b48e-43a3-8bee-9c80cbad301d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://www.bits-pilani.ac.in/admissions/integrated-first-degree/</value>
      <webElementGuid>938e6db9-0c33-4b8c-b9a6-ba5500c5a651</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Integrated first degree</value>
      <webElementGuid>1cad2ea0-976e-42b7-805f-f0a7f9718c70</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;js&quot;]/body[@class=&quot;page-template page-template-template-campus page-template-template-campus-php page page-id-9279 page-parent noptin mfn-header-template color-custom content-brightness-light input-brightness-light style-default button-default layout-full-width if-modern-overlay subheader-both-center mobile-tb-center mobile-side-slide mobile-mini-mr-ll mobile-icon-user-ss mobile-icon-wishlist-ss mobile-icon-search-ss mobile-icon-wpml-ss mobile-icon-action-ss be-page-9279 be-reg-26408 menu_open09&quot;]/div[@class=&quot;sidebar09 show&quot;]/div[@class=&quot;sidebar09_row&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;tabs_wrapper09 navsmTab&quot;]/div[@class=&quot;tabs_container09&quot;]/div[@class=&quot;tab_content09&quot;]/div[@class=&quot;sidebar09_col_sm&quot;]/div[@class=&quot;innav_row&quot;]/div[@class=&quot;innav_col&quot;]/div[@class=&quot;innav_l&quot;]/a[1]</value>
      <webElementGuid>99f772bc-e019-40dc-add4-8be8f4d44ac2</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>(//a[contains(text(),'Integrated first degree')])[4]</value>
      <webElementGuid>508ee6e9-cc9b-4198-8d71-803029854aef</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Admission'])[3]/following::a[1]</value>
      <webElementGuid>4f697b4f-4afc-46c4-a55c-7922c16b61e2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Picture Gallery'])[3]/following::a[1]</value>
      <webElementGuid>076d0396-560e-4e94-8049-21c28ef59b3e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Higher degree'])[3]/preceding::a[1]</value>
      <webElementGuid>03488e21-ad03-49a2-8a5a-6a5b872c47cd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Doctorol programmes'])[1]/preceding::a[2]</value>
      <webElementGuid>e384ea37-c45c-4730-87d0-0358878907a3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>(//a[contains(@href, 'https://www.bits-pilani.ac.in/admissions/integrated-first-degree/')])[3]</value>
      <webElementGuid>7712db45-e3a8-496e-9650-9e5d329e938c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/div[2]/div/div[2]/a</value>
      <webElementGuid>2a69d75b-abbe-48dc-8046-65ce28708f95</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://www.bits-pilani.ac.in/admissions/integrated-first-degree/' and (text() = 'Integrated first degree' or . = 'Integrated first degree')]</value>
      <webElementGuid>d9dd585a-6023-4b72-b920-d432c25a0138</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
