<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Research  Innovation</name>
   <tag></tag>
   <elementGuidId>66bde200-2d72-45fa-a732-d0db92b95cde</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(//a[contains(text(),'Research &amp; Innovation')])[2]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>li.active > a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Research &amp; Innovation&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>916119bc-162d-4b2d-93b0-026d773f993c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>#tab-f4</value>
      <webElementGuid>38f64ac2-05fa-4184-9d19-abe8a2819ac2</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-toggle</name>
      <type>Main</type>
      <value>tab_hover</value>
      <webElementGuid>0d6bded7-919e-4e5a-81b7-00aae6366b5e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Research &amp; Innovation</value>
      <webElementGuid>779ef682-92c7-4d3c-b19c-75fe34747f45</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;js&quot;]/body[@class=&quot;news_post-template-default single single-news_post postid-7752 noptin color-custom content-brightness-light input-brightness-light style-default button-default layout-full-width if-modern-overlay header-classic sticky-header sticky-tb-color ab-hide menu-link-color menuo-right subheader-both-center mobile-tb-center mobile-side-slide mobile-mini-mr-ll mobile-icon-user-ss mobile-icon-wishlist-ss mobile-icon-search-ss mobile-icon-wpml-ss mobile-icon-action-ss be-page-7752 be-reg-26408 mfn-header-scrolled fixed-breadcrumb&quot;]/footer[1]/div[@class=&quot;container&quot;]/div[@class=&quot;list_tab&quot;]/div[@class=&quot;lst_links&quot;]/ul[1]/li[@class=&quot;active&quot;]/a[1]</value>
      <webElementGuid>fe3c0620-0e3f-4b56-ad14-c0c8139e6609</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>(//a[contains(text(),'Research &amp; Innovation')])[2]</value>
      <webElementGuid>de101abc-05bc-4a53-b582-71c609357c09</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Academics'])[3]/following::a[1]</value>
      <webElementGuid>dc97da6a-e72f-42e7-868a-dd034db2cf8a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Policies &amp; Procedures'])[1]/following::a[2]</value>
      <webElementGuid>1cf66612-0888-49fa-adc7-a34855a635c1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Downloads'])[1]/preceding::a[1]</value>
      <webElementGuid>efa4281d-279c-47b4-b2f0-744691604259</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Contacts'])[2]/preceding::a[2]</value>
      <webElementGuid>4dd82645-2ad6-4b64-ad0a-4b30b46e0555</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '#tab-f4')]</value>
      <webElementGuid>0b6d2087-e0d4-4e18-86db-affdb0b55146</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//footer/div/div[3]/div/ul/li[4]/a</value>
      <webElementGuid>2405cf31-2761-4e49-bbd6-e52d821c91f8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '#tab-f4' and (text() = 'Research &amp; Innovation' or . = 'Research &amp; Innovation')]</value>
      <webElementGuid>a1be12c9-9eb7-4cdf-b237-682208a846c7</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
