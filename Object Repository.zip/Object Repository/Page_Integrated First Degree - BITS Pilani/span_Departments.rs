<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Departments</name>
   <tag></tag>
   <elementGuidId>f4e78f4d-22b1-483d-9a24-e9ff56e95562</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Keep Exploring'])[1]/following::span[1]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.navfooter_link.keepex_s2.b_sb > a > span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Departments 1&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>3925440e-bf6f-439c-9ac6-4b14d2b8b520</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Departments</value>
      <webElementGuid>74d5dc17-9149-4822-80e6-006a28cfe9fe</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;js&quot;]/body[@class=&quot;page-template-default page page-id-7997 page-child parent-pageid-8022 noptin mfn-header-template color-custom content-brightness-light input-brightness-light style-default button-default layout-full-width if-modern-overlay subheader-both-center mobile-tb-center mobile-side-slide mobile-mini-mr-ll mobile-icon-user-ss mobile-icon-wishlist-ss mobile-icon-search-ss mobile-icon-wpml-ss mobile-icon-action-ss be-page-7997 be-reg-26408 mfn-header-scrolled fixed-breadcrumb&quot;]/div[@class=&quot;navfooter&quot;]/div[@class=&quot;navfooter_link keepex_s2 b_sb&quot;]/a[1]/span[1]</value>
      <webElementGuid>ba5503cd-ed12-478e-b71a-7c19c5b38e41</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Keep Exploring'])[1]/following::span[1]</value>
      <webElementGuid>ad16af8b-0ea0-48f9-be0e-db1aab058182</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Loading...'])[1]/following::span[2]</value>
      <webElementGuid>91997d95-ad28-4c82-8d53-c1072c3834f6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Events'])[4]/preceding::span[1]</value>
      <webElementGuid>7a8af5f4-048a-4732-9ab2-a831d774f44b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='News'])[4]/preceding::span[2]</value>
      <webElementGuid>b9979a5f-5c85-4f6f-b4ca-046ee7c10f14</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Departments']/parent::*</value>
      <webElementGuid>21100552-8a6c-440b-9569-f17761e65239</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/a/span</value>
      <webElementGuid>6637df76-7bf2-4ce4-8782-83699c99a487</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Departments' or . = 'Departments')]</value>
      <webElementGuid>03492577-369d-43e6-9807-a8b4f9b4303d</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
