<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>p_BITS Pilani is a Deemed to be University,_bce9fe</name>
   <tag></tag>
   <elementGuidId>8c26dcf5-17f4-4b0b-a11b-7ead6387ac3b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='Content']/div/div/div/div/div[3]/div[2]/div[2]/div/div[3]/div/div/p</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.mcb-column-inner.mcb-column-inner-f864a05a1.mcb-item-column-inner > div.column_attr.mfn-inline-editor.clearfix > p</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;BITS Pilani is a Deemed to be University, offering on-campus programs to more th&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>p</value>
      <webElementGuid>da7406b5-5972-4d26-8e79-fd7dd60dbe6f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>BITS Pilani is a Deemed to be University, offering on-campus programs to more than 18,500 students across its campuses in Pilani, Goa, Hyderabad, Mumbai and Dubai. It has been recognized as an Institute of Eminence by the Ministry of Education, Government of India in 2020.</value>
      <webElementGuid>d3d529cc-f1bb-49c2-9714-19501e171d4b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;Content&quot;)/div[@class=&quot;content_wrapper clearfix&quot;]/div[@class=&quot;sections_group&quot;]/div[@class=&quot;entry-content&quot;]/div[@class=&quot;mfn-builder-content mfn-default-content-buider&quot;]/div[@class=&quot;section mcb-section mfn-default-section mcb-section-144fd3d2f default-width&quot;]/div[@class=&quot;section_wrapper mcb-section-inner mcb-section-inner-144fd3d2f&quot;]/div[@class=&quot;wrap mcb-wrap mcb-wrap-543b7e771 one-second tablet-one-second mobile-one clearfix&quot;]/div[@class=&quot;mcb-wrap-inner mcb-wrap-inner-543b7e771&quot;]/div[@class=&quot;column mcb-column mcb-item-f864a05a1 one tablet-one mobile-one column_column&quot;]/div[@class=&quot;mcb-column-inner mcb-column-inner-f864a05a1 mcb-item-column-inner&quot;]/div[@class=&quot;column_attr mfn-inline-editor clearfix&quot;]/p[1]</value>
      <webElementGuid>cc290408-beb3-457a-9c0e-c902418e3f79</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='Content']/div/div/div/div/div[3]/div[2]/div[2]/div/div[3]/div/div/p</value>
      <webElementGuid>bdefdbed-bb93-4c3d-972c-c177b60ddd18</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Integrated First Degree'])[7]/following::p[1]</value>
      <webElementGuid>9f6b800d-dc9a-48d9-9c7b-eaadc0d99c31</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Click here'])[9]/following::p[2]</value>
      <webElementGuid>cee215b7-d4d3-41dd-a94d-9fd18f9ca754</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='visit BITSAT'])[1]/preceding::p[2]</value>
      <webElementGuid>2e40fcb3-a4ba-4897-afc0-5051ce412b01</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Programs'])[1]/preceding::p[6]</value>
      <webElementGuid>92fbc8c6-3ff9-400f-8f76-25b9251034e3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='BITS Pilani is a Deemed to be University, offering on-campus programs to more than 18,500 students across its campuses in Pilani, Goa, Hyderabad, Mumbai and Dubai. It has been recognized as an Institute of Eminence by the Ministry of Education, Government of India in 2020.']/parent::*</value>
      <webElementGuid>368b014a-d070-46e2-8f6d-01f82156035d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/div[3]/div/div/p</value>
      <webElementGuid>f9e28f11-1c90-487c-951a-4be97a9618ef</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//p[(text() = 'BITS Pilani is a Deemed to be University, offering on-campus programs to more than 18,500 students across its campuses in Pilani, Goa, Hyderabad, Mumbai and Dubai. It has been recognized as an Institute of Eminence by the Ministry of Education, Government of India in 2020.' or . = 'BITS Pilani is a Deemed to be University, offering on-campus programs to more than 18,500 students across its campuses in Pilani, Goa, Hyderabad, Mumbai and Dubai. It has been recognized as an Institute of Eminence by the Ministry of Education, Government of India in 2020.')]</value>
      <webElementGuid>96e96a44-c36f-48a5-95aa-37bc1200b44d</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
