<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>li_Programmes Offered</name>
   <tag></tag>
   <elementGuidId>5234547d-846e-4424-b5e9-8c06de431afd</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//header[@id='myfix_header']/div/div[2]/ul/li[3]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>li >> internal:has-text=&quot;Programmes Offered&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>li</value>
      <webElementGuid>a1bd7c8d-9236-44f1-a452-9d4f1c0c6070</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>header_nav_lk </value>
      <webElementGuid>f1f734fc-9a22-45f6-b5c5-b4d05042047d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Programmes Offered </value>
      <webElementGuid>fa947f74-130b-408b-9004-cddf975332e7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;myfix_header&quot;)/div[@class=&quot;micro-header_cover&quot;]/div[@class=&quot;h-links micro-menu-links&quot;]/ul[@class=&quot;micro-header_nav&quot;]/li[@class=&quot;header_nav_lk&quot;]</value>
      <webElementGuid>c160c601-cd1b-406e-8275-8b36209454aa</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//header[@id='myfix_header']/div/div[2]/ul/li[3]</value>
      <webElementGuid>6c474e5f-09bd-4ffe-810d-dc9b8d7f1183</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='DST TEC Centres'])[1]/following::li[1]</value>
      <webElementGuid>30a3462d-be97-469d-9a9f-e402c89e26db</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Partners Institutions'])[1]/following::li[2]</value>
      <webElementGuid>edaab593-43e8-49b3-b3ce-e1f05da107bc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Application'])[1]/preceding::li[1]</value>
      <webElementGuid>c2fd338e-2da9-409c-b100-cb670792eafa</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[3]</value>
      <webElementGuid>94160063-49c0-42f7-9256-0af6036aa17a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//li[(text() = 'Programmes Offered ' or . = 'Programmes Offered ')]</value>
      <webElementGuid>974b4629-b56d-4839-b574-3efd57ee254c</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
