<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Events</name>
   <tag></tag>
   <elementGuidId>4d5b1cc8-ca2a-4216-ab05-f69a1a04c7e4</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Faculty'])[5]/following::span[1]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.navfooter_link.keepex_s3.b_r > a > span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Events 1&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>68321ea5-24cf-48df-a505-91ce6285e5b5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Events</value>
      <webElementGuid>8aa2742d-4b4e-4878-9885-bbf17fb0133f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;js&quot;]/body[@class=&quot;news_post-template-default single single-news_post postid-3062518 noptin color-custom content-brightness-light input-brightness-light style-default button-default layout-full-width if-modern-overlay header-classic sticky-header sticky-tb-color ab-hide menu-link-color menuo-right subheader-both-center mobile-tb-center mobile-side-slide mobile-mini-mr-ll mobile-icon-user-ss mobile-icon-wishlist-ss mobile-icon-search-ss mobile-icon-wpml-ss mobile-icon-action-ss be-page-3062518 be-reg-26408 fixed-breadcrumb mfn-header-scrolled&quot;]/div[@class=&quot;navfooter&quot;]/div[@class=&quot;navfooter_link keepex_s3 b_r&quot;]/a[1]/span[1]</value>
      <webElementGuid>f071516d-4666-4712-aaac-b711a182832e</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Faculty'])[5]/following::span[1]</value>
      <webElementGuid>c9ab4a3c-1aab-49ed-a903-9fb09acaae98</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Keep Exploring'])[1]/following::span[2]</value>
      <webElementGuid>53061681-1ea2-4282-8a46-e633a99a91e1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='News'])[6]/preceding::span[1]</value>
      <webElementGuid>7acb33f6-2b91-4bee-a2a2-6e517335c23d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Are you sure?'])[1]/preceding::span[2]</value>
      <webElementGuid>e675fe5d-bc69-41c6-9f20-7ebfdbec1652</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/a/span</value>
      <webElementGuid>fa90b89d-f381-4b52-a0fd-ef8f1e677b2c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Events' or . = 'Events')]</value>
      <webElementGuid>49ac810f-3195-4e74-b6ed-11ee5750ef03</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
