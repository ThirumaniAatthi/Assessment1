<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Faculty</name>
   <tag></tag>
   <elementGuidId>81c40cc6-3f5b-4c29-9765-51a5b511d348</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Keep Exploring'])[1]/following::span[1]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.navfooter_link.keepex_s2.b_sb > a > span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Faculty 1&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>8d5e00cd-236b-463e-98a9-ea942cde4ea2</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Faculty</value>
      <webElementGuid>e25a3ad1-c3bb-4e37-b091-0eeb97454352</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;js&quot;]/body[@class=&quot;page-template-default page page-id-530 page-child parent-pageid-1070 noptin mfn-header-template color-custom content-brightness-light input-brightness-light style-default button-default layout-full-width if-modern-overlay subheader-both-center mobile-tb-center mobile-side-slide mobile-mini-mr-ll mobile-icon-user-ss mobile-icon-wishlist-ss mobile-icon-search-ss mobile-icon-wpml-ss mobile-icon-action-ss be-page-530 be-reg-26408 fixed-breadcrumb mfn-header-scrolled&quot;]/div[@class=&quot;navfooter&quot;]/div[@class=&quot;navfooter_link keepex_s2 b_sb&quot;]/a[1]/span[1]</value>
      <webElementGuid>965542c1-6f84-4fa5-8562-30ec62a046d0</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Keep Exploring'])[1]/following::span[1]</value>
      <webElementGuid>56f0fcae-42cb-42b8-9e3a-43ebe6463a63</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Loading...'])[1]/following::span[2]</value>
      <webElementGuid>b59ddc9f-195f-41a5-92ad-60d0313f3833</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Events'])[4]/preceding::span[1]</value>
      <webElementGuid>29cfb2f1-98b3-443e-b757-81fd14123d4d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='News'])[4]/preceding::span[2]</value>
      <webElementGuid>39dcc47c-8daf-4ed4-b7cc-5437a60f6625</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/a/span</value>
      <webElementGuid>4015af06-7f51-4ead-8688-689464e3026d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Faculty' or . = 'Faculty')]</value>
      <webElementGuid>cb00a7d5-2b68-40ae-807d-b85641e7545b</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
