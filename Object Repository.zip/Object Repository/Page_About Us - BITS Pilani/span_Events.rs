<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Events</name>
   <tag></tag>
   <elementGuidId>1515c27b-f19f-4d6d-9574-862b21b18517</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Faculty'])[5]/following::span[1]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.navfooter_link.keepex_s3.b_r > a > span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Events 1&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>b1a2b01a-f281-4661-bc1e-84340dded9ba</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Events</value>
      <webElementGuid>07d7e43f-7689-40d4-940a-15deab34ced7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;js&quot;]/body[@class=&quot;page-template-default page page-id-530 page-child parent-pageid-1070 noptin mfn-header-template color-custom content-brightness-light input-brightness-light style-default button-default layout-full-width if-modern-overlay subheader-both-center mobile-tb-center mobile-side-slide mobile-mini-mr-ll mobile-icon-user-ss mobile-icon-wishlist-ss mobile-icon-search-ss mobile-icon-wpml-ss mobile-icon-action-ss be-page-530 be-reg-26408 fixed-breadcrumb mfn-header-scrolled&quot;]/div[@class=&quot;navfooter&quot;]/div[@class=&quot;navfooter_link keepex_s3 b_r&quot;]/a[1]/span[1]</value>
      <webElementGuid>9b78dcc2-0a95-433a-a75d-0d8b3782443f</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Faculty'])[5]/following::span[1]</value>
      <webElementGuid>a4579d93-ef14-4da7-b544-eebf276145cb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Keep Exploring'])[1]/following::span[2]</value>
      <webElementGuid>03e37e46-e3a8-4583-94aa-f40be13f3572</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='News'])[4]/preceding::span[1]</value>
      <webElementGuid>056893c7-1531-4cfe-b22f-1dd4e4d46488</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Are you sure?'])[1]/preceding::span[2]</value>
      <webElementGuid>d2a180b1-59c7-4650-a649-a98ab5733f46</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/a/span</value>
      <webElementGuid>d5622630-fea4-4aff-858e-c62749812e7e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Events' or . = 'Events')]</value>
      <webElementGuid>96328ee9-45b4-4554-891b-037c5e6ebae5</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
