<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h4_JOINT Ph.D. SCHOLARSHIP  BITS PILANI AND_60f525</name>
   <tag></tag>
   <elementGuidId>4b09b318-a454-401d-aa83-1da36e5f9236</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='Content']/div/div/div/div[2]/div[2]/div/div/ul/div/div/div[5]/div/li/div/div/a/h4</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.slick-slide.slick-current.slick-active > div > li.splide__slide > div.marquee09-tag > div.marquee09_txt > a > h4</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;JOINT Ph.D. SCHOLARSHIP – BITS PILANI AND RMIT UNIVERSITY, AUSTRALIA Pilani&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h4</value>
      <webElementGuid>b86303c6-3331-4287-af8b-25feffc4d476</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>JOINT Ph.D. SCHOLARSHIP – BITS PILANI AND RMIT UNIVERSITY, AUSTRALIA</value>
      <webElementGuid>6fc89e28-d136-4a1e-aa4a-f3f442749fdb</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;Content&quot;)/div[@class=&quot;content_wrapper clearfix&quot;]/div[@class=&quot;sections_group&quot;]/div[@class=&quot;details-page-section&quot;]/div[@class=&quot;details-page-banner&quot;]/div[@class=&quot;detail-right-img&quot;]/div[@class=&quot;marquee09&quot;]/div[@class=&quot;splide__track marquee09-content&quot;]/ul[@class=&quot;slick-slider marquee09_slick slick-initialized&quot;]/div[@class=&quot;slick-list draggable&quot;]/div[@class=&quot;slick-track&quot;]/div[@class=&quot;slick-slide slick-current slick-active&quot;]/div[1]/li[@class=&quot;splide__slide&quot;]/div[@class=&quot;marquee09-tag&quot;]/div[@class=&quot;marquee09_txt&quot;]/a[1]/h4[1]</value>
      <webElementGuid>ed59452c-325c-46bf-8fb8-fa3bbf6aed3c</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='Content']/div/div/div/div[2]/div[2]/div/div/ul/div/div/div[5]/div/li/div/div/a/h4</value>
      <webElementGuid>60122d30-7a70-45ef-9781-710437864cdc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='JOINT Ph.D. SCHOLARSHIP – BITS PILANI AND RMIT UNIVERSITY, AUSTRALIA'])[1]/following::h4[1]</value>
      <webElementGuid>24e03b3e-9ec9-40b8-abf7-cd9a52646fb9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Joint PhD program at BITS Pilani and La Trobe University, Australia'])[1]/following::h4[2]</value>
      <webElementGuid>b818ea5f-e476-4909-ae23-45a7e815dd8f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='JOINT PH.D. SCHOLARSHIP – BITS PILANI AND RMIT UNIVERSITY, AUSTRALIA'])[1]/preceding::h4[2]</value>
      <webElementGuid>d0adb376-39e6-4d76-b254-34bc13386a60</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Indian Workshop on Applied Deep Learning (IWADL2019)'])[1]/preceding::h4[3]</value>
      <webElementGuid>3de17539-5bb0-4eda-a7fd-ab8b047c2d54</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[5]/div/li/div/div/a/h4</value>
      <webElementGuid>54c07652-2192-4d8e-b197-45770ba2675a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h4[(text() = 'JOINT Ph.D. SCHOLARSHIP – BITS PILANI AND RMIT UNIVERSITY, AUSTRALIA' or . = 'JOINT Ph.D. SCHOLARSHIP – BITS PILANI AND RMIT UNIVERSITY, AUSTRALIA')]</value>
      <webElementGuid>f4b3e72a-b0df-4a16-9c99-b7b4a8d5a6a1</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
