<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_News</name>
   <tag></tag>
   <elementGuidId>f92d0118-4e75-4385-9125-b82468c7b57e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Events'])[4]/following::span[1]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.navfooter_link.keepex_s4.b_y > a > span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;News 1&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>10c3f184-b6e0-4488-8b99-004569a1fc26</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>News</value>
      <webElementGuid>bdc63e52-63cf-4981-aad6-08942e75fea7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;js&quot;]/body[@class=&quot;page-template page-template-template-practice-school page-template-template-practice-school-php page page-id-5721 noptin mfn-header-template color-custom content-brightness-light input-brightness-light style-default button-default layout-full-width if-modern-overlay subheader-both-center mobile-tb-center mobile-side-slide mobile-mini-mr-ll mobile-icon-user-ss mobile-icon-wishlist-ss mobile-icon-search-ss mobile-icon-wpml-ss mobile-icon-action-ss be-page-5721 be-reg-26408 fixed-breadcrumb mfn-header-scrolled&quot;]/div[@class=&quot;navfooter&quot;]/div[@class=&quot;navfooter_link keepex_s4 b_y&quot;]/a[1]/span[1]</value>
      <webElementGuid>7acd321f-9731-4cba-8745-3a51a932c44a</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Events'])[4]/following::span[1]</value>
      <webElementGuid>d1581bc7-de86-413c-8967-d1c9e2b4828b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Faculty'])[5]/following::span[2]</value>
      <webElementGuid>a5000a8b-2d7b-46ce-a4af-7949fcb218c4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Are you sure?'])[1]/preceding::span[1]</value>
      <webElementGuid>035b40af-e9e3-4141-956d-afb5ad17940c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Subscribe'])[1]/preceding::span[1]</value>
      <webElementGuid>044cf619-d2f8-4680-a6f1-8205b53dba0f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[4]/a/span</value>
      <webElementGuid>d224851a-6320-4861-9c28-f57abfdd269d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'News' or . = 'News')]</value>
      <webElementGuid>b585b4c4-7dc0-4361-99b7-147e0b19671b</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
