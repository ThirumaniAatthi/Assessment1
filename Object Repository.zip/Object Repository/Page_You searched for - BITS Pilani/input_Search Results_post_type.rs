<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>input_Search Results_post_type</name>
   <tag></tag>
   <elementGuidId>28c98de4-3a0f-4d04-a192-daabf290cfe4</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//input[@value='Campus / Dept.']</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=button[name=&quot;Campus / Dept.&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>input</value>
      <webElementGuid>729c8782-7498-4893-86f3-8f6909fe6cb3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>type</name>
      <type>Main</type>
      <value>button</value>
      <webElementGuid>f6920cd7-04fe-4fc6-96e9-58b867ca63d0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>post_type </value>
      <webElementGuid>c0d4be30-8d80-4d8a-a2a7-6bb5c4f02bb0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>value</name>
      <type>Main</type>
      <value>Campus / Dept.</value>
      <webElementGuid>a23e5de9-dcdc-4e4f-998f-88c87a8d7bd5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>slug</name>
      <type>Main</type>
      <value>campus</value>
      <webElementGuid>3af8bf08-9773-4146-8768-3a5fb0164c09</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;js&quot;]/body[@class=&quot;search search-results noptin mfn-header-template color-custom content-brightness-light input-brightness-light style-default button-default layout-full-width if-modern-overlay subheader-both-center mobile-tb-center mobile-side-slide mobile-mini-mr-ll mobile-icon-user-ss mobile-icon-wishlist-ss mobile-icon-search-ss mobile-icon-wpml-ss mobile-icon-action-ss be-page- be-reg-26408 fixed-breadcrumb mfn-header-scrolled&quot;]/section[1]/div[@class=&quot;container&quot;]/div[@class=&quot;insd_sec_cnt&quot;]/div[@class=&quot;filter-row&quot;]/div[@class=&quot;filter-col12&quot;]/input[@class=&quot;post_type&quot;]</value>
      <webElementGuid>7a5d3b1a-ae8e-4484-97a5-d355d3ce3fa5</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//input[@value='Campus / Dept.']</value>
      <webElementGuid>21e34d78-25a3-4ad0-9f80-1e7e6a8cb58a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/div/div/div/input[2]</value>
      <webElementGuid>2838c013-f0e3-4cd8-9a11-92748cfec0ad</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//input[@type = 'button']</value>
      <webElementGuid>9d447e5d-cba8-4620-a0fb-ff34eaa7168c</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
